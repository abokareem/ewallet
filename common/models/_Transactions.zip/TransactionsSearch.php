<?php

namespace backend\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Transactions;

/**
 * TransactionsSearch represents the model behind the search form of `common\models\Transactions`.
 */
class TransactionsSearch extends Transactions
{
    public  $senderEmail,
    public  $recipientEmail,
    public  $senderWalletCurrency,
    public  $recipientWalletCurrency,
    public  $senderWalletName,
    public  $recipientWalletName,


    public function attributes()//для практики попробовал другой методзадавания атрибута
    {
        // делаем поле зависимости доступным для поиска
        return array_merge(parent::attributes(), ['users_wallets.name']);
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'sender_wallet_id', 'recipient_wallet_id'], 'integer'],
            [['sender_currency_amount', 'recipient_currency_amount'], 'number'],
            [['timestamp'], 'safe'],
            // [['senderEmail', 'recipientEmail', 'senderWalletCurrency', 'recipientWalletCurrency', 'senderWalletName', 'recipientWalletName'], 'safe'],      //

        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class

        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Transactions::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->joinWith(['users_wallets']);
        $query->joinWith(['users']);
        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            // 'sender_wallet_id' => $this->sender_wallet_id,
            // 'recipient_wallet_id' => $this->recipient_wallet_id,
            'sender_currency_amount' => $this->sender_currency_amount,
            'recipient_currency_amount' => $this->recipient_currency_amount,
            // 'timestamp' => $this->timestamp,
            // 'senderEmail' => $this->senderWallet->senderId->email,
            // 'recipientEmail' => $this->recipientWallet->recipientId->email,
            // 'senderWalletCurrency' => $this->users_wallets->currency,
            // 'recipientWalletCurrency' => $this->users_wallets->currency,
            // 'senderWalletName' => $this->users_wallets->name,
            // 'recipientWalletName' => $this->users_wallets->name,
        ]);
// $query->joinWith(['users_wallets']);
        // $query->joinWith(['senderWallet' => function($query) { $query->from(['senderWallet' => 'users_wallets']);
        // $query->joinWith(['recipientWallet' => function($query) { $query->from(['recipientWallet' => 'users_wallets']);
}]);
        // $query->joinWith('users')->joinWith('users_wallets')->joinWith('currency');
        // $query->leftJoin('{{%users_wallets}}', 'users_wallets.id = transactions.sender_wallet_id')
            // ->andFilterWhere(['LIKE', 'users_wallets.item_name', $this->access]);



        // $query->andFilterWhere(['like', 'senderWallet.user.email', $this->senderEmail]);
        $query->andFilterWhere(['like', 'senderWallet.senderId.email', $this->getAttribute('senderWallet.user.senderEmail')]);

        // $query->andFilterWhere(['like', 'senderWallet.senderEmail', $this->getAttribute('senderWallet.senderEmail')]);
        // $query->andFilterWhere(['like', 'senderEmail', $this->senderWallet->recipientId->email])
            // ->andFilterWhere(['like', 'recipientEmail', $this->recipientWallet->recipientId->email])
            // ->andFilterWhere(['LIKE', 'users.username', $this->getAttribute('branch.name')])
            ;

        // $query->leftJoin('{{%auth_assignment}}', 'auth_assignment.user_id = user.id')
        //     ->andFilterWhere(['LIKE', 'auth_assignment.item_name', $this->access]);

            // 'senderEmail' => $this->senderEmail,
            // 'recipientEmail' => $this->recipientEmail,
            // 'senderWalletCurrency' => $this->senderWalletCurrency,
            // 'recipientWalletCurrency' => $this->recipientWalletCurrency,
            // 'senderWalletName' => $this->senderWalletName,
            // 'recipientWalletName' => $this->recipientWalletName,

            //         'senderEmail' => $this->users->email->andwhere('id', 'sender_wallet_id'),
            // 'recipientEmail' => $this->users->email->andwhere('id', 'recipient_wallet_id'),
            // 'senderWalletCurrency' => $this->users_wallets->currency->andwhere('id', 'sender_wallet_id'),
            // 'recipientWalletCurrency' => $this->users_wallets->currency->andwhere('id', 'recipient_wallet_id'),
            // 'senderWalletName' => $this->users_wallets->name->andwhere('id', 'sender_wallet_id'),
            // 'recipientWalletName' => $this->users_wallets->name->andwhere('id', 'recipient_wallet_id'),


        // добавляем сортировку по колонке из зависимости
        $dataProvider->sort->attributes['senderEmail.email'] = [
        'asc' => ['senderEmail.email' => SORT_ASC],
        'desc' => ['senderEmail.email' => SORT_DESC],
        ];

        return $dataProvider;
    }
}
